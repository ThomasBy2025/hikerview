import http from 'http';

// 全局错误处理，防止进程崩溃
process.on('unhandledRejection', (reason, promise) => {
    console.error('[Process] 未处理的 Promise 拒绝:', reason)
})
process.on('uncaughtException', (error) => {
    console.error('[Process] 未捕获的异常:', error.message)
})


// 音源初始化，创建本地代理
const startServer = async () => {
    const LxSource = await import('./lxsource.cjs');
    try {
        LxSource.loadAllScripts(); // 音源初始化
    } catch (error) {
        console.error('[Init] 音源初始化失败:', error.message)
    }


    // 格式化songInfo
    function normalizeSongInfo(songInfo) {
        const normalized = {
            ...songInfo
        }
        if (songInfo.meta) {
            Object.assign(normalized, songInfo.meta)
            if (songInfo.meta.songId && !normalized.songmid) normalized.songmid = songInfo.meta.songId
            if (songInfo.meta.picUrl && !normalized.img) normalized.img = songInfo.meta.picUrl
            if (songInfo.meta.hash && !normalized.hash) normalized.hash = songInfo.meta.hash
            if (songInfo.meta.albumId && !normalized.albumId) normalized.albumId = songInfo.meta.albumId
            if (songInfo.meta.copyrightId && !normalized.copyrightId) normalized.copyrightId = songInfo.meta.copyrightId
            if (songInfo.meta.strMediaMid && !normalized.strMediaMid) normalized.strMediaMid = songInfo.meta.strMediaMid
            if (songInfo.meta.albumMid && !normalized.albumMid) normalized.albumMid = songInfo.meta.albumMid
            if (songInfo.meta.lrcUrl && !normalized.lrcUrl) normalized.lrcUrl = songInfo.meta.lrcUrl
            if (songInfo.meta.mrcUrl && !normalized.mrcUrl) normalized.mrcUrl = songInfo.meta.mrcUrl
            if (songInfo.meta.trcUrl && !normalized.trcUrl) normalized.trcUrl = songInfo.meta.trcUrl
        }
        return normalized
    }


    // 请求音源链接
    async function getMusicUrl(info, Sources = false) {
        const source = info.musicInfo.source;
        const sources = Sources || LxSource.getSources(source);
        info.musicInfo = normalizeSongInfo(info.musicInfo);
        for (const api of sources) {
            try { // 音源存在音质才加载
                if (api.info.sources[source].qualitys.includes(info.type)) {
                    const result = await api.callRequest({
                        action: "musicUrl",
                        source: source,
                        info: info
                    });
                    const url = (result && typeof result === 'object') ?
                        (result.url || result.musicUrl || result.src || result.data) : result;
                    if (url && typeof url === 'string') {
                        return JSON.stringify({
                            url
                        });
                    }
                }
            } catch (err) {
                console.warn(`[lxsource] ${api.info.name}-${info.type} 获取链接失败:`, err.message);
            }
        }
        return "{}"; // 所有任务都失败
    }


    // 加载特定音源
    async function loadSource(info) {
        if (info.type == "debug") {
            const Sources = [LxSource.getSourceId(info.scriptId)].filter(Boolean);
            if (Sources.length === 0) {
                return '{"url":"音源未启用，无法测试"}';
            }
            info.type = info.quality;
            const url = await getMusicUrl(info, Sources, true);
            return url;
        }
        if (info.type == "shutSource") {
            return await LxSource.shutSource(info.scriptId);
        }
        if (info.type == "update") {
            return await LxSource.updateSource(info.scriptId);
        }
        if (info.type == "delete") {
            await LxSource.updateDelete(info.scriptId);
        }
        const fs = require('fs');
        const path = require('path');
        const scriptPath = path.join(__dirname, 'node_sources', info.scriptId);
        if (!fs.existsSync(scriptPath)) {
            console.warn(`[lxsource] 加载失败 ✘`, `音源无法读取`);
            return "{}";
        }
        const script = fs.readFileSync(scriptPath, 'utf-8');
        const success = await LxSource.loadSource({ // 重新挂载音源
            id: info.scriptId,
            script
        }, true);
        return JSON.stringify(success);
    }


    // 创建本地代理
    const port = 1999;
    const host = "0.0.0.0";
    const server = http.createServer((req, res) => {
        res.writeHead(200, {
            'Content-Type': 'application/json'
        });

        // 检查路径和方法
        if (req.url !== '/lxmusic') {
            return res.end(JSON.stringify({
                error: '未知的PATH请求'
            }));
        }
        if (req.method !== 'POST') {
            return res.end(JSON.stringify({
                error: '请使用POST请求'
            }));
        }

        let body = ''; // 接收数据
        req.on('data', chunk => {
            body += chunk.toString();
        });
        req.on('end', async () => {
            try {
                const parsedBody = JSON.parse(body);
                if (parsedBody.scriptId) {
                    const run = await loadSource(parsedBody);
                    res.end(run);
                } else {
                    const url = await getMusicUrl(parsedBody);
                    res.end(url);
                }
            } catch (e) {
                if (e instanceof SyntaxError) {
                    res.end(JSON.stringify({
                        error: '请求体不是JSON'
                    }));
                } else {
                    res.end(JSON.stringify({
                        error: '获取操作失败',
                        details: e.message
                    }));
                }
            }
        });
    });
    server.listen(port, host, () => {
        console.log(`[lxserver] 服务已启动:\nPOST http://${host}:${port}/lxmusic { type, musicInfo }\n`);
    });
    const shutdown = (signal) => {
        console.log(`[lxserver] 收到 ${signal} 信号，正在关闭服务...`)
        server.close(() => {
            console.log('[lxserver] 服务已关闭')
        })
        setTimeout(() => {
            console.log('[lxserver] 强制退出…')
            process.exit(0)
        }, 5000)
    }
    process.on('SIGINT', () => shutdown('SIGINT'));
    process.on('SIGTERM', () => shutdown('SIGTERM'));
}
startServer().catch(err => {
    console.error('❌ 启动失败:', err)
    process.exit(1)
})