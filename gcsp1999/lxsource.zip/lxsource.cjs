const { VM } = require('vm2')
const fs = require('fs')
const path = require('path')
const needle = require('needle')
const crypto = require('crypto')
const zlib = require('zlib')
const { promisify } = require('util')
const inflate = promisify(zlib.inflate)
const deflate = promisify(zlib.deflate)


// 格式化resultObj
function decontextify(obj) {
    if (obj === null || obj === undefined) return obj
    if (typeof obj !== 'object') return obj
    try {
        if (Buffer.isBuffer(obj) || obj instanceof Uint8Array || (obj && obj.constructor && obj.constructor.name === 'Buffer')) {
            return Buffer.from(Uint8Array.from(obj))
        }
    } catch (e) {}
    if (Array.isArray(obj)) {
        try {
            return obj.map(item => decontextify(item))
        } catch (e) {
            return []
        }
    }
    if (obj instanceof Error || (obj && obj.constructor && obj.constructor.name === 'Error')) {
        const err = new Error(obj.message)
        err.stack = obj.stack
        return err
    }
    try {
        const newObj = {}
        const keys = Object.keys(obj)
        for (const key of keys) {
            try {
                newObj[key] = decontextify(obj[key])
            } catch (e) {}
        }
        return newObj
    } catch (e) {
        try {
            const str = JSON.stringify(obj)
            return str ? JSON.parse(str) : String(obj)
        } catch (e2) {
            return String(obj)
        }
    }
}


// 格式化scriptMeta
function extractMetadata(script) {
    const meta = {}
    const commentMatch = script.match(/\/\*[*!]([\s\S]*?)\*\//)
    if (commentMatch) {
        const comment = commentMatch[1]
        const nameMatch = comment.match(/@name\s+(.+)/)
        if (nameMatch) meta.name = nameMatch[1].trim()
        const descMatch = comment.match(/@description\s+(.+)/)
        if (descMatch) meta.description = descMatch[1].trim()
        const verMatch = comment.match(/@version\s+(.+)/)
        if (verMatch) meta.version = verMatch[1].trim()
        const authorMatch = comment.match(/@author\s+(.+)/)
        if (authorMatch) meta.author = authorMatch[1].trim()
        const repoMatch = comment.match(/@(?:repository|homepage)\s+(.+)/)
        if (repoMatch) meta.homepage = repoMatch[1].trim()
    }
    if (!meta.name) {
        const platMatch = script.match(/platform\s*[:=]\s*['"]([^'"]+)['"]/)
        if (platMatch) meta.name = platMatch[1].trim()
    }
    if (!meta.version) {
        const verMatch2 = script.match(/version\s*[:=]\s*['"]([^'"]+)['"]/)
        if (verMatch2) meta.version = verMatch2[1].trim()
    }
    if (!meta.author) {
        const authMatch2 = script.match(/author\s*[:=]\s*['"]([^'"]+)['"]/)
        if (authMatch2) meta.author = authMatch2[1].trim()
    }
    return meta
}


// 音源环境模拟
function getLxObject(lxDataInside) {
    return {
        send: null,
        on: null,
        ...lxDataInside,
        utils: {
            buffer: {
                from: (d, e) => Buffer.from(decontextify(d), decontextify(e)),
                bufToString: (b, f) => Buffer.isBuffer(b) ? b.toString(f) : Buffer.from(b, 'binary').toString(f)
            },
            crypto: {
                md5: (str) => crypto.createHash('md5').update((decontextify(str) || '')).digest('hex'),
                aesEncrypt: (buffer, mode, key, iv) => {
                    const dKey = decontextify(key);
                    const dIv = decontextify(iv);
                    const dBuffer = decontextify(buffer)
                    const algorithm = `aes-${dKey.length * 8}-${mode}`
                    const cipher = crypto.createCipheriv(algorithm, dKey, dIv)
                    return Buffer.concat([cipher.update(dBuffer), cipher.final()])
                },
                rsaEncrypt: (buffer, key) => crypto.publicEncrypt(decontextify(key), decontextify(buffer)),
                randomBytes: (size) => crypto.randomBytes(size),
            },
            zlib: {
                inflate: (buffer) => inflate(decontextify(buffer)),
                deflate: (buffer) => deflate(decontextify(buffer))
            }
        },
        request: (url, options, callback) => {
            const safeOptions = decontextify(options || {})
            const {
                method = 'get', timeout, headers, body, form, formData, rejectUnauthorized
            } = safeOptions
            let requestOptions = {
                headers,
                response_timeout: typeof timeout === 'number' && timeout > 0 ? Math.min(timeout, 60000) : 60000,
                rejectUnauthorized: rejectUnauthorized !== undefined ? rejectUnauthorized : false,
            }
            let data = body
            if (form) {
                data = form;
                requestOptions.json = false
            } else if (formData) {
                data = formData;
                requestOptions.json = false
            }
            const request = needle.request(method, url, data, requestOptions, (err, resp, body) => {
                try {
                    if (err) {
                        callback.call(null, decontextify(err), null, null)
                    } else {
                        let parsedBody = body
                        if (typeof body === 'string') {
                            try {
                                parsedBody = JSON.parse(body)
                            } catch {}
                        }
                        let safeResp = {
                            statusCode: resp.statusCode,
                            statusMessage: resp.statusMessage,
                            headers: resp.headers,
                            body: decontextify(parsedBody)
                        }
                        callback.call(null, null, safeResp, safeResp.body)
                    }
                } catch (error) {
                    callback.call(null, decontextify(error), null, null)
                }
            })
            return () => {
                const reqObj = request.request;
                if (reqObj && !reqObj.aborted) reqObj.abort()
            }
        }
    }
}


// 沙箱环境设置
function getSandbox(lxObject) {
    const safeConsole = {
        log: console.log.bind(console),
        info: console.info.bind(console),
        warn: console.warn.bind(console),
        error: console.error.bind(console),
        debug: console.debug ? console.debug.bind(console) : console.log.bind(console),
        group: console.group ? console.group.bind(console) : (() => {}),
        groupEnd: console.groupEnd ? console.groupEnd.bind(console) : (() => {}),
        groupCollapsed: console.groupCollapsed ? console.groupCollapsed.bind(console) : (() => {}),
        trace: console.trace ? console.trace.bind(console) : console.log.bind(console),
        dir: console.dir ? console.dir.bind(console) : console.log.bind(console),
        table: console.table ? console.table.bind(console) : console.log.bind(console),
        time: console.time ? console.time.bind(console) : (() => {}),
        timeEnd: console.timeEnd ? console.timeEnd.bind(console) : (() => {}),
        count: console.count ? console.count.bind(console) : (() => {}),
        countReset: console.countReset ? console.countReset.bind(console) : (() => {}),
        assert: console.assert ? console.assert.bind(console) : (() => {}),
        clear: console.clear ? console.clear.bind(console) : (() => {}),
    }
    return {
        console: safeConsole,
        setTimeout,
        clearTimeout,
        setInterval,
        clearInterval,
        Buffer,
        URL,
        URLSearchParams,
        TextEncoder,
        TextDecoder,
        process: {
            nextTick: (fn, ...args) => setTimeout(() => fn(...args), 0),
            env: {
                NODE_ENV: 'production'
            },
            on: (event, handler) => {
                if (event === 'unhandledRejection') {
                    process.on('unhandledRejection', (reason, promise) => {
                        console.error(`[lxsource] 未处理的 Promise 拒绝:`, reason)
                        if (initReject) initReject(new Error(`脚本运行错误：${reason}`))
                    })
                }
            }
        },
        Lx: lxObject,
        lx: lxObject,
        require: (mod) => {
            if (mod === 'https' || mod === 'http') return require(mod)
            if (mod === 'url') return require(mod)
            if (mod === 'crypto') return crypto
            if (mod === 'zlib') return zlib
            if (mod === 'path') return require(mod)
            if (mod === 'stream') return require(mod)
            if (mod === 'buffer') return {
                Buffer
            }
            throw new Error(`模块 ${mod} 不允许在沙箱中加载`)
        },

        global: null,
        window: null,
        globalThis: null,
        atob: (s) => Buffer.from(s, 'base64').toString('binary'),
        btoa: (s) => Buffer.from(s, 'binary').toString('base64'),
        crypto: crypto,
        XMLHttpRequest: undefined,
        fetch: async (url, options) => {
            const opts = options || {}
            const method = (opts.method || 'GET').toUpperCase()
            const headers = opts.headers || {}
            const body = opts.body
            const needleOpts = {
                headers,
                response_timeout: 30000,
                rejectUnauthorized: false,
                json: false,
            }
            return new Promise((resolve, reject) => {
                needle.request(method, url, body, needleOpts, (err, resp, respBody) => {
                    if (err) return reject(err)
                    const ok = resp.statusCode >= 200 && resp.statusCode < 300
                    const response = {
                        ok,
                        status: resp.statusCode,
                        statusText: resp.statusMessage || '',
                        headers: resp.headers || {},
                        url,
                        _rawBody: respBody,
                        json() {
                            try {
                                return Promise.resolve(typeof respBody === 'string' ? JSON.parse(respBody) : respBody)
                            } catch (e) {
                                return Promise.reject(e)
                            }
                        },
                        text() {
                            return Promise.resolve(typeof respBody === 'string' ? respBody : (Buffer.isBuffer(respBody) ? respBody.toString('utf-8') : String(respBody)))
                        },
                    }
                    resolve(response)
                })
            })
        }
    }
}




const updateMap = new Map();
const sourceMap = new Map();
const loadedApis = new Map();// 挂载列表
const initCache = new Map();// 缓存挂载
const INIT_CACHE_TTL = 60000


// 加载音源
async function loadSource(apiInfo, skipCache = false) {
  const cacheKey = apiInfo.id
  const now = Date.now()

  if (skipCache) {
    initCache.delete(cacheKey)
  }

  const cached = initCache.get(cacheKey)
  if (!skipCache && cached) {
    if (cached.loading) {// 已加载
      return cached.promise
    }
    if (cached.success && (now - cached.timestamp < INIT_CACHE_TTL)) {// 有缓存
      return cached.result
    }
    if (cached.failed && (now - cached.timestamp < INIT_CACHE_TTL)) {// 失败过
      return cached.result
    }
  }


  const metadata = extractMetadata(apiInfo.script)
  const fullApiInfo = { ...apiInfo, ...metadata }
  const eventHandlers = new Map()
  let registeredSources = {}
  let initResolve = null
  let initReject = null
  const initPromise = new Promise((resolve, reject) => { initResolve = resolve; initReject = reject })

  initCache.set(cacheKey, { loading: true, timestamp: now, promise: initPromise })


  // 音源环境函数
  const lxObject = getLxObject({
    version: '2.0.0', env: 'desktop', platform: 'web',
    currentScriptInfo: { name: fullApiInfo.name, description: fullApiInfo.description, version: fullApiInfo.version, author: fullApiInfo.author, homepage: fullApiInfo.homepage, rawScript: fullApiInfo.script },
    EVENT_NAMES: { request: 'request', inited: 'inited', updateAlert: 'updateAlert' }
  });
  lxObject.on = (eventName, handler) => {
      if (eventName === 'request') {
        eventHandlers.set(eventName, handler)
      }
    };
  lxObject.send = (eventName, data) => {
      const dData = decontextify(data)
      if (eventName === 'inited') {
        if (dData && dData.sources) {
          registeredSources = dData.sources;

          Object.keys(registeredSources).forEach(sourceKey=>{
            if(!sourceMap.has(sourceKey)){
               sourceMap.set(sourceKey, []);
            }
            sourceMap.get(sourceKey).push(fullApiInfo.id);
          });
        }
        if (initResolve) initResolve()
      } else if (eventName === 'updateAlert') {
        updateMap.set(fullApiInfo.id, JSON.stringify(dData));
        console.warn(`[lxsource] 音源有更新:\n`, JSON.stringify(dData))
        if (initReject) initReject(new Error(`发现新版本,需要更新: ${JSON.stringify(dData)}`))
      }
    }

  const sandbox = getSandbox(lxObject);
  sandbox.global = sandbox
  sandbox.window = sandbox
  sandbox.globalThis = sandbox



  try {
      try {// 注册vm2环境
        const vmInstance = new VM({ timeout: 10000, sandbox, eval: true, wasm: false });
        vmInstance.run(`
          (function() {
            try {
              ${apiInfo.script}
            } catch (e) {
              console.error('[lxsource] 加载失败 ✘ 脚本执行错误:', e.message);
              throw e;
            }
          })();
        `);
      } catch (e) {
        const isContextError = e.message.includes('contextified object') || e.message.includes('Operation not allowed')
        if (isContextError) {
          console.warn(`[lxsource] 加载失败 ✘`, `触发 vm2 安全限制`)
          throw new Error('REQUIRE_UNSAFE_VM')
        }
        throw e
      }
    


    try {
      await Promise.race([
        initPromise, 
        new Promise((_, reject) => setTimeout(() => reject(new Error('初始化超时（10秒）')), 10000))
      ])
    } catch (initError) {
      console.error(`[lxsource] 加载失败 ✘ 无法初始化:`, initError.message)
      throw initError
    }


// 挂载函数为全局变量
    const apiInstance = {
      info: { ...fullApiInfo, sources: registeredSources },
      handlers: eventHandlers,
      callRequest: async (inputData) => {
        try {
          const handler = eventHandlers.get('request')
          if (!handler) throw new Error(`源 ${fullApiInfo.name} 未注册 request 处理器`)
          const result = await handler(inputData)
          return decontextify(result)
        } catch (e) {
          console.error(`[UserApi-${fullApiInfo.name}] callRequest Error:`, e.message)
          throw e
        }
      }
    }
    loadedApis.set(apiInfo.id, apiInstance);



    console.log(`[lxsource] 加载成功 ✔︎\n支持: ${Object.keys(registeredSources).join(', ')}`)
    
    initCache.set(cacheKey, { 
      loading: false, 
      success: true, 
      timestamp: Date.now(), 
      result: { success: true, apiInstance, error: null } 
    })
    
    return { success: true, apiInstance, error: null }
  } catch (error) {
    console.error(`[lxsource] 加载失败 ✘`, error.message)

    initCache.set(cacheKey, { 
      loading: false, 
      failed: true, 
      timestamp: Date.now(), 
      result: { success: false, apiInstance: null, error: error.message, requireUnsafe: error.message === 'REQUIRE_UNSAFE_VM' } 
    })
    
    return { success: false, apiInstance: null, error: error.message, requireUnsafe: error.message === 'REQUIRE_UNSAFE_VM' }
  }
}


// 初始化音源列表
async function loadAllScripts() {
    const scriptRoot = path.join(__dirname, 'node_sources'); // 音源总路径
    const sortPath = path.join(__dirname, 'sorted.json'); // 排序后列表
    const openPath = path.join(__dirname, 'enableds.json'); // 启用源列表
    console.log(`[lxsource] 从本地加载音源`)
    loadedApis.clear();
    sourceMap.clear();
    updateMap.clear();
    try {
        const sortData = JSON.parse(fs.readFileSync(sortPath, 'utf-8'));
        const openData = JSON.parse(fs.readFileSync(openPath, 'utf-8'));
        for (const scriptId of sortData) {
            console.log(`[lxsource] ========================================`);
            console.log(`[lxsource] 正在加载 ...\n${scriptId}`)
            if (!openData[scriptId]) {
                console.log(`[lxsource] 加载失败 ✘\n音源没有启用`)
                continue
            }
            const scriptPath = path.join(scriptRoot, scriptId);
            if (!fs.existsSync(scriptPath)) {
                console.warn(`[lxsource] 加载失败 ✘`, `音源无法读取`)
                continue
            }
            try {
                const script = fs.readFileSync(scriptPath, 'utf-8');
                const result = await loadSource({ // 挂载音源
                    id: scriptId,
                    script
                });
            } catch (error) {}
        }
    } catch (error) {
        console.error(`[lxsource] 读取异常 ✘`, error.message)
    }
    console.log(`[lxsource] ========================================`)
}


// 注销源
function shutSource(scriptId) {
    initCache.delete(scriptId);
    loadedApis.delete(scriptId);
    updateMap.delete(scriptId);
    for (const [key, ids] of sourceMap) {
        const filteredIds = ids.filter(id => id !== scriptId);
        if (filteredIds.length === 0) {
            sourceMap.delete(key);
        } else {
            sourceMap.set(key, filteredIds);
        }
    }
    return 'ok'
}


// 支持source的源
function getSources(source) {
    const candidates = [];
    const apiIds = sourceMap.get(source) || [];
    for (const apiId of apiIds) {
        candidates.push(loadedApis.get(apiId));
    }
    return candidates
}

// 指定source
function getSourceId(apiId) {
    return loadedApis.get(apiId);
}


// 支持update的源
function updateSource(scriptId) {
    return updateMap.get(scriptId) || "{}";
}

// 注销update
function updateDelete(scriptId) {
    return updateMap.delete(scriptId), "ok";
}


module.exports = {
    loadAllScripts,
    loadSource,
    shutSource,
    getSources,
    getSourceId,
    updateSource,
    updateDelete,
    extractMetadata
}